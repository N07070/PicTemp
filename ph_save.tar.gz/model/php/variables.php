<?php

$mysql_user = "derp";
$mysql_user_password = "derp";
$mysql_database_name = "pic_temp";
$mysql_user_table_name = "pic_temp_user";
$mysql_pictures_table_name = "pic_temp_images";

?>
